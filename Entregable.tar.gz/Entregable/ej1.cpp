#include <bits/stdc++.h>

using namespace std;
 
struct tupNumero
{
    int numero;
    int arreglo; //0 1 2 = n r a
    tupNumero(int num, int arr) : numero(num),arreglo(arr){}
};

struct tupBoolNumero
{
	bool usado;
	int numero;
};

void mostrarVector(vector<int>& vec){
    for (int i = 0; i < vec.size(); ++i)
    {
        cout<<vec[i]<<" ";
    }
    cout<<endl;
 }
using namespace std;

bool esCrec(vector<int>& v){
    bool res = true;
    if (v.size()==0){
    	return true;
    }
    for (int i = 0; i < v.size()-1; ++i)
    {
        res=res && (v[i]<v[i+1]);
    }
    return res;
}

bool esDec(vector<int>& v){
    bool res = true;
    if (v.size()==0){
    	return true;
    }

    for (int i = 0; i < v.size()-1; ++i)
    {
        res=res && (v[i]>v[i+1]);
    }
    return res;
}


bool esSolucion(vector<int >& crec, vector<int>& dec){
    return esCrec(crec) && esDec(dec);
}

int estudiarCaso(vector<tupNumero>& v){
	int sinUsar= v.size();
	vector<int> rojos;
	vector<int> azules;	

	for (int i = 0; i < sinUsar; ++i)
	{
		if(v[i].arreglo==1){
			rojos.push_back(v[i].numero);
		}else if(v[i].arreglo==2){
			azules.push_back(v[i].numero);
		}
	}
	if(esSolucion(rojos,azules)){
		sinUsar= sinUsar-rojos.size()-azules.size();
	}
	return sinUsar;
}

int min3(int a, int b, int c){
	if(a<b){
		if(a<c){
			return a;
		}else{
			return c;
		}
	}else{
		if(b<c){
			return b;
		}else{
			return c;
		}
	}
}



int bt_recur(vector<tupNumero> &arr, int n, int i, vector<tupNumero> &v){
	vector<tupNumero> caminoRojo=v;
	vector<tupNumero> caminoAzul=v;


	int posible1;
	int posible2;
	int posible3;
	int sol1;
	int sol2;
	int sol3;

	int valor=arr[i].numero;

	tupNumero nada(valor,0);
	tupNumero roja(valor,1);
	tupNumero azul(valor,2);

	
	v.push_back(nada);
	caminoRojo.push_back(roja);
	caminoAzul.push_back(azul);


	i++;


	if(i==n){
		

		posible1 = estudiarCaso(v);
		posible2 = estudiarCaso(caminoRojo);
		posible3 = estudiarCaso(caminoAzul);


		int minimoHastaAca = min3(posible3,posible2,posible1);
		
		return minimoHastaAca;
	}else{
	

		sol1= bt_recur(arr,n,i,v);
		sol2= bt_recur(arr,n,i,caminoRojo);
		sol3= bt_recur(arr,n,i,caminoAzul);

		int minimoOptimo =min3(sol1,sol2,sol3);
		
		return minimoOptimo;
	}

}

int backtracking (vector<tupNumero> &arr, int n){
	vector<tupNumero> v;
	int i=0;

	return bt_recur(arr,n,i,v);
}

int main(int argc, char const *argv[]){
using namespace std;
	cout<<"Por favor ingresa la ruta del archivo de entrada: "<<endl;
	string nombreFIle;
	ifstream input;
  	cin>>nombreFIle;
    input.open(nombreFIle.c_str());
    string aux;
    int n;
    int h;
    getline(input,aux);
    n=atoi(aux.c_str());
    vector<tupNumero> data;
    for (int i = 0; i < n; ++i){
    	getline(input,aux,' ');
    	h=atoi(aux.c_str());
    	tupNumero numero(h,0);
        data.push_back(numero);
    }
    cout<<backtracking(data,data.size());      
}