#include <iostream>
#include <string>
#include <fstream>
#include <bits/stdc++.h>


using namespace std;

int min3(int a, int b, int c){
	if(a<b){
		if(a<c){
			return a;
		}else{
			return c;
		}
	}else{
		if(b<c){
			return b;
		}else{
			return c;
		}
	}
}

int bt_recur_acot(vector<int> &arr,int n, int i, bool rojoUsado,int ultimoRojo, bool azulUsado,int ultimoAzul, int noUsado){
	int auxR=n;
	int auxA=n;
	int auxN=n;
	int mejorSol;
	if(i==n){
		return noUsado;
	}else{
		//caso ROJO
		if(rojoUsado==false){
			auxR=bt_recur_acot(arr,n,i+1,true,arr[i],azulUsado,ultimoAzul,noUsado);
		}else{
			if(ultimoRojo<arr[i]){
			//puede ser rojo
				auxR=bt_recur_acot(arr,n,i+1,rojoUsado,arr[i],azulUsado,ultimoAzul,noUsado);
			}else{
				//NO puede ser rojo
			}
		}

		//Caso Azul
		if(azulUsado==false){
			auxA=bt_recur_acot(arr,n,i+1,rojoUsado,ultimoRojo,true,arr[i],noUsado);
		}else{
			//veo si puede ser azul
			if(ultimoAzul>arr[i]){
				//puede
				auxA=bt_recur_acot(arr,n,i+1,rojoUsado,ultimoRojo,azulUsado,arr[i],noUsado);
			}else{
				//No puede ser AZUL
			}
		}

		//Caso Nada
		auxN=bt_recur_acot(arr,n,i+1,rojoUsado,ultimoRojo,azulUsado,ultimoAzul,noUsado+1);

		mejorSol = min3(auxR,auxA,auxN);

	}

}

int backtracking_cota (vector<int> &arr, int n){
	bool bfalse=false;
	return bt_recur_acot(arr,n,0,false,0,false,0,0);
}	


int main(int argc, char const *argv[]){
using namespace std;
	cout<<"Por favor ingresa la ruta del archivo de entrada: "<<endl;
	string nombreFIle;
	ifstream input;
  	cin>>nombreFIle;
    input.open(nombreFIle.c_str());
    string aux;
    int n;
    int h;
    getline(input,aux);
    n=atoi(aux.c_str());
    vector<int>dataInt;
    for (int i = 0; i < n; ++i){
    	getline(input,aux,' ');
    	h=atoi(aux.c_str());
    	dataInt.push_back(h);
    }

    cout<<backtracking_cota(dataInt,dataInt.size());
        
}