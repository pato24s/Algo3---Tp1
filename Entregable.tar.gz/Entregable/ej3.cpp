#include <iostream>
#include <string>
#include <fstream>
#include <bits/stdc++.h>


using namespace std;
int dp[203][203][203];
int a[204];
int N;

int rec(int dec, int inc, int idx){
    if(idx == N) {
        return 0;
    }
    if(dp[dec][inc][idx] != -1) return dp[dec][inc][idx];
    int ret = 0;
    if(a[dec] > a[idx]){
        ret = max(ret, 1 + rec(idx, inc, idx+1));
    }
    if(a[inc] < a[idx]){
        ret = max(ret, 1 + rec(dec, idx, idx+1));
    } 
    ret = max(ret, rec(dec, inc, idx+1));
    dp[dec][inc][idx] = ret;
    return ret;
}

int programacionDinamica(vector<int> &arr){
	// 	memset(dp, -1, sizeof dp);


	N=arr.size();

	for (int i = 0; i < N; ++i)	{
		a[i]=arr[i];
	}
	a[N] = -1;
	a[N+1] = 1234567;
	for(int i=0;i<=N+1;++i){
		for(int j=0;j<=N+1;++j){
	        for(int k=0;k<=N+1;++k){
	            dp[i][j][k] = -1;
	        }
	    }
	}
	return N- rec(N+1,N,0);
}

int main(int argc, char const *argv[]){
using namespace std;
	cout<<"Por favor ingresa la ruta del archivo de entrada: "<<endl;
	string nombreFIle;
	ifstream input;
  	cin>>nombreFIle;
    input.open(nombreFIle.c_str());
    string aux;
    int n;
    int h;
    getline(input,aux);
    n=atoi(aux.c_str());
    vector<int>dataInt;
    for (int i = 0; i < n; ++i){
    	getline(input,aux,' ');
    	h=atoi(aux.c_str());
    	dataInt.push_back(h);
    }

    cout<<programacionDinamica(dataInt);
        
}